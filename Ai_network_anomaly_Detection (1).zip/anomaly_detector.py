import os
import urllib.request
import warnings

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense

warnings.filterwarnings("ignore")

TRAIN_FILE = "KDDTrain+.txt"
TEST_FILE = "KDDTest+.txt"

DATA_URLS = {
    TRAIN_FILE: "https://raw.githubusercontent.com/defcom17/NSL_KDD/master/KDDTrain%2B.txt",
    TEST_FILE: "https://raw.githubusercontent.com/defcom17/NSL_KDD/master/KDDTest%2B.txt",
}

columns = [
    "duration","protocol_type","service","flag","src_bytes","dst_bytes",
    "land","wrong_fragment","urgent","hot","num_failed_logins","logged_in",
    "num_compromised","root_shell","su_attempted","num_root","num_file_creations",
    "num_shells","num_access_files","num_outbound_cmds","is_host_login",
    "is_guest_login","count","srv_count","serror_rate","srv_serror_rate",
    "rerror_rate","srv_rerror_rate","same_srv_rate","diff_srv_rate",
    "srv_diff_host_rate","dst_host_count","dst_host_srv_count",
    "dst_host_same_srv_rate","dst_host_diff_srv_rate","dst_host_same_src_port_rate",
    "dst_host_srv_diff_host_rate","dst_host_serror_rate","dst_host_srv_serror_rate",
    "dst_host_rerror_rate","dst_host_srv_rerror_rate","label","difficulty"
]

def download_if_missing(filename: str) -> None:
    if os.path.exists(filename):
        print(f"[+] Found {filename}")
        return
    print(f"[!] Missing {filename}")
    print(f"[*] Downloading {filename}...")
    urllib.request.urlretrieve(DATA_URLS[filename], filename)
    print(f"[+] Downloaded {filename}")

def main():
    print("[*] Checking dataset files...")
    download_if_missing(TRAIN_FILE)
    download_if_missing(TEST_FILE)

    print("[*] Loading dataset...")
    train = pd.read_csv(TRAIN_FILE, names=columns)
    test = pd.read_csv(TEST_FILE, names=columns)

    train["label"] = train["label"].apply(lambda x: 0 if x == "normal" else 1)
    test["label"] = test["label"].apply(lambda x: 0 if x == "normal" else 1)

    drop_cols = ["protocol_type", "service", "flag", "label", "difficulty"]
    X_train = train.drop(columns=drop_cols).values
    X_test = test.drop(columns=drop_cols).values
    y_test = test["label"].values

    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    X_normal = X_train[train["label"].values == 0]

    print(f"[*] Training on {len(X_normal)} normal samples...")

    dim = X_normal.shape[1]
    inp = Input(shape=(dim,))
    x = Dense(32, activation="relu")(inp)
    x = Dense(16, activation="relu")(x)
    x = Dense(8, activation="relu")(x)
    x = Dense(16, activation="relu")(x)
    x = Dense(32, activation="relu")(x)
    out = Dense(dim, activation="sigmoid")(x)

    autoencoder = Model(inp, out)
    autoencoder.compile(optimizer="adam", loss="mse")

    history = autoencoder.fit(
        X_normal, X_normal,
        epochs=30,
        batch_size=256,
        validation_split=0.1,
        verbose=1
    )

    autoencoder.save("autoencoder_model.keras")

    recon = autoencoder.predict(X_normal)
    mse_train = np.mean(np.power(X_normal - recon, 2), axis=1)
    threshold = float(np.percentile(mse_train, 95))

    with open("threshold.txt", "w") as f:
        f.write(str(threshold))

    print(f"[*] Threshold: {threshold:.6f}")

    recon_test = autoencoder.predict(X_test)
    mse_test = np.mean(np.power(X_test - recon_test, 2), axis=1)
    y_pred = (mse_test > threshold).astype(int)

    print("\n=== Classification Report ===")
    print(classification_report(y_test, y_pred, target_names=["Normal", "Attack"]))

    print("\n=== Confusion Matrix ===")
    print(confusion_matrix(y_test, y_pred))

    df_out = test.copy()
    df_out["reconstruction_error"] = mse_test
    df_out["predicted_anomaly"] = y_pred
    df_out.to_csv("anomaly_results.csv", index=False)

    plt.figure(figsize=(10, 4))
    plt.plot(history.history["loss"], label="Train")
    plt.plot(history.history["val_loss"], label="Validation")
    plt.title("Training Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.tight_layout()
    plt.savefig("training_loss.png")

    plt.figure(figsize=(10, 4))
    plt.hist(mse_test[y_test == 0], bins=100, alpha=0.6, label="Normal")
    plt.hist(mse_test[y_test == 1], bins=100, alpha=0.6, label="Attack")
    plt.axvline(threshold, linestyle="--", label="Threshold")
    plt.title("Reconstruction Error")
    plt.xlabel("MSE Reconstruction Error")
    plt.ylabel("Count")
    plt.legend()
    plt.tight_layout()
    plt.savefig("reconstruction_error.png")

    print("\n[+] Done!")
    print("[+] Created anomaly_results.csv")
    print("[+] Created autoencoder_model.keras")
    print("[+] Created threshold.txt")
    print("[+] Created training_loss.png")
    print("[+] Created reconstruction_error.png")

if __name__ == "__main__":
    main()
