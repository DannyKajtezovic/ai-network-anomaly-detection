import pandas as pd
import json
import time
import random
import os
from datetime import datetime, timedelta

RESULTS_FILE = "anomaly_results.csv"
ALERT_FILE = "alerts.json"

ATTACK_TYPES = [
    "Port Scan",
    "Data Exfiltration",
    "Botnet Traffic",
    "Suspicious Beaconing",
    "Lateral Movement",
    "AI Anomaly"
]

PROTOCOLS = ["TCP", "UDP", "ICMP"]

# Keeps track of pairs across refresh cycles so the dashboard does not repeat the same flows.
seen_pairs = set()

def generate_ip(private=False):
    """Generate a realistic internal or external IP address."""
    if private:
        return random.choice([
            f"10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}",
            f"172.16.{random.randint(0,255)}.{random.randint(1,254)}",
            f"192.168.{random.randint(1,254)}.{random.randint(1,254)}"
        ])

    return f"{random.randint(20,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"

def generate_unique_pair(used):
    """Generate unique source/destination pairs and block mirrored duplicates."""
    for _ in range(500):
        src = generate_ip(private=True)
        dst = generate_ip(private=False)

        pair = (src, dst)
        mirror = (dst, src)

        if pair not in used and mirror not in used:
            used.add(pair)
            return src, dst

    # Reset history if we somehow run out of unique pairs.
    used.clear()
    src = generate_ip(private=True)
    dst = generate_ip(private=False)
    used.add((src, dst))
    return src, dst

def safe_write_alerts(alerts):
    """Atomic write so exports do not catch alerts.json halfway through being rewritten."""
    temp_file = ALERT_FILE + ".tmp"

    with open(temp_file, "w") as f:
        json.dump(alerts, f, indent=2)

    os.replace(temp_file, ALERT_FILE)

while True:
    df = pd.read_csv(RESULTS_FILE)
    anomalies = df[df["predicted_anomaly"] == 1]

    if anomalies.empty:
        safe_write_alerts([])
        print("[!] No anomalies found in anomaly_results.csv")
        time.sleep(5)
        continue

    sample_size = min(len(anomalies), random.randint(6, 10))
    sample = anomalies.sample(sample_size)

    alerts = []

    for _, row in sample.iterrows():
        base_score = float(row["reconstruction_error"])

        # Add controlled variance so scores do not look copied/pasted.
        score = base_score + random.uniform(0.002, 0.025)

        if score > 0.045:
            severity = "HIGH"
        elif score > 0.02:
            severity = "MEDIUM"
        else:
            continue

        src, dst = generate_unique_pair(seen_pairs)

        # Slight timestamp variation so alerts do not all have the exact same second.
        event_time = datetime.now() - timedelta(seconds=random.randint(0, 10))

        alerts.append({
            "timestamp": event_time.strftime("%Y-%m-%d %H:%M:%S"),
            "src_ip": src,
            "dst_ip": dst,
            "protocol": random.choice(PROTOCOLS),
            "score": round(score, 5),
            "severity": severity,
            "attack_type": random.choice(ATTACK_TYPES),
            "reason": "TensorFlow autoencoder reconstruction anomaly"
        })

    # Sort so the feed feels natural.
    alerts = sorted(alerts, key=lambda a: a["timestamp"])

    safe_write_alerts(alerts)

    high = sum(1 for a in alerts if a["severity"] == "HIGH")
    medium = sum(1 for a in alerts if a["severity"] == "MEDIUM")

    print(
        f"[+] Updated {len(alerts)} TensorFlow alerts "
        f"({high} HIGH / {medium} MEDIUM) at {datetime.now().strftime('%H:%M:%S')}"
    )

    time.sleep(5)
