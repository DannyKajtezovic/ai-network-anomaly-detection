# NetGuard AI — Final Capstone Version

## Overview

NetGuard AI is a TensorFlow-powered network anomaly detection platform designed to simulate a modern Security Operations Center (SOC) monitoring environment.

The system combines machine learning, behavioral anomaly detection, real-time dashboard visualization, and exportable security logs into a unified cybersecurity monitoring platform.

The project analyzes network traffic behavior using a TensorFlow autoencoder trained on NSL-KDD network traffic data and identifies anomalous patterns using reconstruction error analysis.

---

# Core Features

## AI-Based Anomaly Detection
- TensorFlow/Keras autoencoder model
- Behavioral anomaly scoring
- Reconstruction error analysis
- Dynamic severity classification

## Real-Time SOC Dashboard
- Live updating alert feed
- High / Medium severity tracking
- Animated cyber-style dashboard UI
- Real-time refresh countdown
- Last update timestamps

## Threat Simulation & Classification
- Port Scan detection
- Data Exfiltration simulation
- Botnet Traffic labeling
- Suspicious Beaconing detection
- Lateral Movement simulation
- AI anomaly classification

## Exportable Security Logs
- Export alerts to JSON
- Export alerts to CSV
- Atomic-safe log writing
- SOC-style reporting capability

## Dashboard Enhancements
- Duplicate alert suppression
- Mirrored traffic prevention
- Dynamic scoring variation
- Timestamp randomization
- Realistic internal/external IP generation

---

# Final Architecture

```text
TensorFlow Autoencoder
        ↓
anomaly_results.csv
        ↓
generate_alerts.py
        ↓
alerts.json
        ↓
Flask API Backend
        ↓
NetGuard AI Dashboard
```

---

# Technologies Used

## Backend
- Python
- Flask
- Flask-CORS
- JSON
- CSV

## Machine Learning
- TensorFlow
- Keras
- NumPy
- Pandas
- Scikit-learn

## Visualization
- HTML5
- CSS3
- JavaScript

## Data & Analysis
- NSL-KDD Dataset
- Autoencoder anomaly detection
- Reconstruction error thresholding

---

# Main Files

```text
dashboard/
└── index.html

anomaly_detector.py
generate_alerts.py
dashboard_server.py

alerts.json
anomaly_results.csv

autoencoder_model.keras
threshold.txt

training_loss.png
reconstruction_error.png

requirements.txt
README.md
```

---

# Setup Instructions

## 1. Create Virtual Environment

```powershell
python -m venv .venv
```

## 2. Activate Environment

```powershell
.\.venv\Scripts\activate
```

## 3. Install Dependencies

```powershell
pip install -r requirements.txt
```

---

# Running the Project

## Terminal 1 — Train AI Model

```powershell
python anomaly_detector.py
```

This creates:
- `autoencoder_model.keras`
- `threshold.txt`
- `anomaly_results.csv`
- `training_loss.png`
- `reconstruction_error.png`

---

## Terminal 2 — Start Dashboard Backend

```powershell
python dashboard_server.py
```

---

## Terminal 3 — Start Live Alert Feed

```powershell
python generate_alerts.py
```

---

# Open Dashboard

```text
http://127.0.0.1:5000
```

---

# Dashboard Capabilities

The dashboard provides:

- Live anomaly monitoring
- Severity classification
- Threat categorization
- Exportable security logs
- SOC-style visualization
- Dynamic scoring display
- Real-time updates

---

# Export Features

Users can export:
- JSON alert logs
- CSV alert reports

These simulate enterprise SOC reporting and SIEM log exports.

---

# Educational Purpose

This project was developed for cybersecurity learning, anomaly detection research, and SOC dashboard simulation purposes.

The platform demonstrates:
- Machine learning integration in cybersecurity
- Network anomaly detection concepts
- Security monitoring workflows
- SIEM/SOC-inspired dashboard engineering
- Behavioral threat analysis

---

# Portfolio Description

Developed a TensorFlow-powered network anomaly detection system capable of analyzing behavioral traffic anomalies using autoencoder reconstruction error analysis. Built a real-time SOC-style dashboard with live alert visualization, severity classification, exportable logs, and simulated threat intelligence workflows using Python, Flask, TensorFlow, and JavaScript.

---

# Future Improvements

Potential future enhancements include:
- GeoIP threat mapping
- Threat intelligence integration
- Real packet capture analysis
- PCAP upload support
- SQLite/PostgreSQL logging
- Authentication system
- Historical analytics
- Live charts and graphs
- Cloud deployment
- SIEM integrations

---

# Authors

Ali Ahsan  
Danny Kajtezovic

B.S. Cybersecurity — Lewis University

NetGuard AI Capstone Project
