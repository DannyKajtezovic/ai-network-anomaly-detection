from flask import Flask, jsonify, send_from_directory, Response
from flask_cors import CORS
import json
import csv
import io
import os

app = Flask(__name__, static_folder="dashboard")
CORS(app)

ALERT_LOG = "alerts.json"

def load_alerts():
    if not os.path.exists(ALERT_LOG):
        return []
    try:
        with open(ALERT_LOG) as f:
            return json.load(f)
    except json.JSONDecodeError:
        return []

@app.route("/")
def index():
    return send_from_directory("dashboard", "index.html")

@app.route("/api/alerts")
def get_alerts():
    return jsonify(load_alerts()[-100:])

@app.route("/api/stats")
def get_stats():
    data = load_alerts()
    return jsonify({
        "total": len(data),
        "high": sum(1 for a in data if a.get("severity") == "HIGH"),
        "medium": sum(1 for a in data if a.get("severity") == "MEDIUM")
    })

@app.route("/export/json")
def export_json():
    data = load_alerts()
    return Response(
        json.dumps(data, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": "attachment; filename=netguard_alerts.json"}
    )

@app.route("/export/csv")
def export_csv():
    data = load_alerts()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["timestamp", "src_ip", "dst_ip", "protocol", "score", "severity", "attack_type", "reason"])

    for a in data:
        writer.writerow([
            a.get("timestamp", ""),
            a.get("src_ip", a.get("src", "")),
            a.get("dst_ip", a.get("dst", "")),
            a.get("protocol", a.get("proto", "")),
            a.get("score", ""),
            a.get("severity", ""),
            a.get("attack_type", ""),
            a.get("reason", "")
        ])

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=netguard_alerts.csv"}
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
